#include "StudentsList.h"

StudentsList::StudentsList()
{
	first = NULL;	
	last = NULL;
}
